/* eslint-disable no-unused-vars */
import React, { useState } from "react";
import GoogleMapEmbed from "./component/GoogleMapEmbed";
import PartiularPlacesSearch from "./component/partiularPlacesSearch";
import StreatView from "./component/StreatView";
import BusTimingsTable from "./component/busTable";

const App = () => {
  return (
    <div className="my-5">
      <PartiularPlacesSearch />

      <GoogleMapEmbed />
      <StreatView />
      <BusTimingsTable />
    </div>
  );
};

export default App;
